package com.example.em_ambu;

public class PayPalConfig {

    public static final String PAYAPAL_CLIENT_ID = "AXugiNgwO7IIP89tdv45HbcqHaiglORcLAXSUU0o3-Xtdjcd8QCo6W3q0TveZ8bOgv_cLEB4GTs5Dsi2";
}
